function L(t) {
  let i = t.length;
  for (; --i >= 0; )
    t[i] = 0;
}
const nt = 3, at = 258, He = 29, ft = 256, ot = ft + 1 + He, Be = 30, st = 512, lt = new Array((ot + 2) * 2);
L(lt);
const rt = new Array(Be * 2);
L(rt);
const ct = new Array(st);
L(ct);
const dt = new Array(at - nt + 1);
L(dt);
const ht = new Array(He);
L(ht);
const ut = new Array(Be);
L(ut);
const wt = (t, i, e, o) => {
  let r = t & 65535 | 0, n = t >>> 16 & 65535 | 0, d = 0;
  for (; e !== 0; ) {
    d = e > 2e3 ? 2e3 : e, e -= d;
    do
      r = r + i[o++] | 0, n = n + r | 0;
    while (--d);
    r %= 65521, n %= 65521;
  }
  return r | n << 16 | 0;
};
var ae = wt;
const xt = () => {
  let t, i = [];
  for (var e = 0; e < 256; e++) {
    t = e;
    for (var o = 0; o < 8; o++)
      t = t & 1 ? 3988292384 ^ t >>> 1 : t >>> 1;
    i[e] = t;
  }
  return i;
}, _t = new Uint32Array(xt()), bt = (t, i, e, o) => {
  const r = _t, n = o + e;
  t ^= -1;
  for (let d = o; d < n; d++)
    t = t >>> 8 ^ r[(t ^ i[d]) & 255];
  return t ^ -1;
};
var O = bt, fe = {
  2: "need dictionary",
  /* Z_NEED_DICT       2  */
  1: "stream end",
  /* Z_STREAM_END      1  */
  0: "",
  /* Z_OK              0  */
  "-1": "file error",
  /* Z_ERRNO         (-1) */
  "-2": "stream error",
  /* Z_STREAM_ERROR  (-2) */
  "-3": "data error",
  /* Z_DATA_ERROR    (-3) */
  "-4": "insufficient memory",
  /* Z_MEM_ERROR     (-4) */
  "-5": "buffer error",
  /* Z_BUF_ERROR     (-5) */
  "-6": "incompatible version"
  /* Z_VERSION_ERROR (-6) */
}, Fe = {
  /* Allowed flush values; see deflate() and inflate() below for details */
  Z_NO_FLUSH: 0,
  Z_FINISH: 4,
  Z_BLOCK: 5,
  Z_TREES: 6,
  /* Return codes for the compression/decompression functions. Negative values
  * are errors, positive values are used for special but normal events.
  */
  Z_OK: 0,
  Z_STREAM_END: 1,
  Z_NEED_DICT: 2,
  Z_STREAM_ERROR: -2,
  Z_DATA_ERROR: -3,
  Z_MEM_ERROR: -4,
  Z_BUF_ERROR: -5,
  /* The deflate compression method */
  Z_DEFLATED: 8
  //Z_NULL:                 null // Use -1 or null inline, depending on var type
};
const kt = (t, i) => Object.prototype.hasOwnProperty.call(t, i);
var gt = function(t) {
  const i = Array.prototype.slice.call(arguments, 1);
  for (; i.length; ) {
    const e = i.shift();
    if (e) {
      if (typeof e != "object")
        throw new TypeError(e + "must be non-object");
      for (const o in e)
        kt(e, o) && (t[o] = e[o]);
    }
  }
  return t;
}, vt = (t) => {
  let i = 0;
  for (let o = 0, r = t.length; o < r; o++)
    i += t[o].length;
  const e = new Uint8Array(i);
  for (let o = 0, r = 0, n = t.length; o < n; o++) {
    let d = t[o];
    e.set(d, r), r += d.length;
  }
  return e;
}, Ge = {
  assign: gt,
  flattenChunks: vt
};
let Ke = !0;
try {
  String.fromCharCode.apply(null, new Uint8Array(1));
} catch {
  Ke = !1;
}
const H = new Uint8Array(256);
for (let t = 0; t < 256; t++)
  H[t] = t >= 252 ? 6 : t >= 248 ? 5 : t >= 240 ? 4 : t >= 224 ? 3 : t >= 192 ? 2 : 1;
H[254] = H[255] = 1;
var Et = (t) => {
  if (typeof TextEncoder == "function" && TextEncoder.prototype.encode)
    return new TextEncoder().encode(t);
  let i, e, o, r, n, d = t.length, s = 0;
  for (r = 0; r < d; r++)
    e = t.charCodeAt(r), (e & 64512) === 55296 && r + 1 < d && (o = t.charCodeAt(r + 1), (o & 64512) === 56320 && (e = 65536 + (e - 55296 << 10) + (o - 56320), r++)), s += e < 128 ? 1 : e < 2048 ? 2 : e < 65536 ? 3 : 4;
  for (i = new Uint8Array(s), n = 0, r = 0; n < s; r++)
    e = t.charCodeAt(r), (e & 64512) === 55296 && r + 1 < d && (o = t.charCodeAt(r + 1), (o & 64512) === 56320 && (e = 65536 + (e - 55296 << 10) + (o - 56320), r++)), e < 128 ? i[n++] = e : e < 2048 ? (i[n++] = 192 | e >>> 6, i[n++] = 128 | e & 63) : e < 65536 ? (i[n++] = 224 | e >>> 12, i[n++] = 128 | e >>> 6 & 63, i[n++] = 128 | e & 63) : (i[n++] = 240 | e >>> 18, i[n++] = 128 | e >>> 12 & 63, i[n++] = 128 | e >>> 6 & 63, i[n++] = 128 | e & 63);
  return i;
};
const pt = (t, i) => {
  if (i < 65534 && t.subarray && Ke)
    return String.fromCharCode.apply(null, t.length === i ? t : t.subarray(0, i));
  let e = "";
  for (let o = 0; o < i; o++)
    e += String.fromCharCode(t[o]);
  return e;
};
var yt = (t, i) => {
  const e = i || t.length;
  if (typeof TextDecoder == "function" && TextDecoder.prototype.decode)
    return new TextDecoder().decode(t.subarray(0, i));
  let o, r;
  const n = new Array(e * 2);
  for (r = 0, o = 0; o < e; ) {
    let d = t[o++];
    if (d < 128) {
      n[r++] = d;
      continue;
    }
    let s = H[d];
    if (s > 4) {
      n[r++] = 65533, o += s - 1;
      continue;
    }
    for (d &= s === 2 ? 31 : s === 3 ? 15 : 7; s > 1 && o < e; )
      d = d << 6 | t[o++] & 63, s--;
    if (s > 1) {
      n[r++] = 65533;
      continue;
    }
    d < 65536 ? n[r++] = d : (d -= 65536, n[r++] = 55296 | d >> 10 & 1023, n[r++] = 56320 | d & 1023);
  }
  return pt(n, r);
}, Rt = (t, i) => {
  i = i || t.length, i > t.length && (i = t.length);
  let e = i - 1;
  for (; e >= 0 && (t[e] & 192) === 128; )
    e--;
  return e < 0 || e === 0 ? i : e + H[t[e]] > i ? e : i;
}, oe = {
  string2buf: Et,
  buf2string: yt,
  utf8border: Rt
};
function At() {
  this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
}
var mt = At;
const G = 16209, St = 16191;
var Tt = function(i, e) {
  let o, r, n, d, s, y, a, f, m, x, l, u, S, g, _, p, b, c, E, T, h, R, v, w;
  const k = i.state;
  o = i.next_in, v = i.input, r = o + (i.avail_in - 5), n = i.next_out, w = i.output, d = n - (e - i.avail_out), s = n + (i.avail_out - 257), y = k.dmax, a = k.wsize, f = k.whave, m = k.wnext, x = k.window, l = k.hold, u = k.bits, S = k.lencode, g = k.distcode, _ = (1 << k.lenbits) - 1, p = (1 << k.distbits) - 1;
  e:
    do {
      u < 15 && (l += v[o++] << u, u += 8, l += v[o++] << u, u += 8), b = S[l & _];
      t:
        for (; ; ) {
          if (c = b >>> 24, l >>>= c, u -= c, c = b >>> 16 & 255, c === 0)
            w[n++] = b & 65535;
          else if (c & 16) {
            E = b & 65535, c &= 15, c && (u < c && (l += v[o++] << u, u += 8), E += l & (1 << c) - 1, l >>>= c, u -= c), u < 15 && (l += v[o++] << u, u += 8, l += v[o++] << u, u += 8), b = g[l & p];
            i:
              for (; ; ) {
                if (c = b >>> 24, l >>>= c, u -= c, c = b >>> 16 & 255, c & 16) {
                  if (T = b & 65535, c &= 15, u < c && (l += v[o++] << u, u += 8, u < c && (l += v[o++] << u, u += 8)), T += l & (1 << c) - 1, T > y) {
                    i.msg = "invalid distance too far back", k.mode = G;
                    break e;
                  }
                  if (l >>>= c, u -= c, c = n - d, T > c) {
                    if (c = T - c, c > f && k.sane) {
                      i.msg = "invalid distance too far back", k.mode = G;
                      break e;
                    }
                    if (h = 0, R = x, m === 0) {
                      if (h += a - c, c < E) {
                        E -= c;
                        do
                          w[n++] = x[h++];
                        while (--c);
                        h = n - T, R = w;
                      }
                    } else if (m < c) {
                      if (h += a + m - c, c -= m, c < E) {
                        E -= c;
                        do
                          w[n++] = x[h++];
                        while (--c);
                        if (h = 0, m < E) {
                          c = m, E -= c;
                          do
                            w[n++] = x[h++];
                          while (--c);
                          h = n - T, R = w;
                        }
                      }
                    } else if (h += m - c, c < E) {
                      E -= c;
                      do
                        w[n++] = x[h++];
                      while (--c);
                      h = n - T, R = w;
                    }
                    for (; E > 2; )
                      w[n++] = R[h++], w[n++] = R[h++], w[n++] = R[h++], E -= 3;
                    E && (w[n++] = R[h++], E > 1 && (w[n++] = R[h++]));
                  } else {
                    h = n - T;
                    do
                      w[n++] = w[h++], w[n++] = w[h++], w[n++] = w[h++], E -= 3;
                    while (E > 2);
                    E && (w[n++] = w[h++], E > 1 && (w[n++] = w[h++]));
                  }
                } else if ((c & 64) === 0) {
                  b = g[(b & 65535) + (l & (1 << c) - 1)];
                  continue i;
                } else {
                  i.msg = "invalid distance code", k.mode = G;
                  break e;
                }
                break;
              }
          } else if ((c & 64) === 0) {
            b = S[(b & 65535) + (l & (1 << c) - 1)];
            continue t;
          } else if (c & 32) {
            k.mode = St;
            break e;
          } else {
            i.msg = "invalid literal/length code", k.mode = G;
            break e;
          }
          break;
        }
    } while (o < r && n < s);
  E = u >> 3, o -= E, u -= E << 3, l &= (1 << u) - 1, i.next_in = o, i.next_out = n, i.avail_in = o < r ? 5 + (r - o) : 5 - (o - r), i.avail_out = n < s ? 257 + (s - n) : 257 - (n - s), k.hold = l, k.bits = u;
};
const M = 15, le = 852, re = 592, ce = 0, J = 1, de = 2, Dt = new Uint16Array([
  /* Length codes 257..285 base */
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  13,
  15,
  17,
  19,
  23,
  27,
  31,
  35,
  43,
  51,
  59,
  67,
  83,
  99,
  115,
  131,
  163,
  195,
  227,
  258,
  0,
  0
]), Ot = new Uint8Array([
  /* Length codes 257..285 extra */
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  16,
  17,
  17,
  17,
  17,
  18,
  18,
  18,
  18,
  19,
  19,
  19,
  19,
  20,
  20,
  20,
  20,
  21,
  21,
  21,
  21,
  16,
  199,
  75
]), Ct = new Uint16Array([
  /* Distance codes 0..29 base */
  1,
  2,
  3,
  4,
  5,
  7,
  9,
  13,
  17,
  25,
  33,
  49,
  65,
  97,
  129,
  193,
  257,
  385,
  513,
  769,
  1025,
  1537,
  2049,
  3073,
  4097,
  6145,
  8193,
  12289,
  16385,
  24577,
  0,
  0
]), It = new Uint8Array([
  /* Distance codes 0..29 extra */
  16,
  16,
  16,
  16,
  17,
  17,
  18,
  18,
  19,
  19,
  20,
  20,
  21,
  21,
  22,
  22,
  23,
  23,
  24,
  24,
  25,
  25,
  26,
  26,
  27,
  27,
  28,
  28,
  29,
  29,
  64,
  64
]), Zt = (t, i, e, o, r, n, d, s) => {
  const y = s.bits;
  let a = 0, f = 0, m = 0, x = 0, l = 0, u = 0, S = 0, g = 0, _ = 0, p = 0, b, c, E, T, h, R = null, v;
  const w = new Uint16Array(M + 1), k = new Uint16Array(M + 1);
  let Z = null, se, B, F;
  for (a = 0; a <= M; a++)
    w[a] = 0;
  for (f = 0; f < o; f++)
    w[i[e + f]]++;
  for (l = y, x = M; x >= 1 && w[x] === 0; x--)
    ;
  if (l > x && (l = x), x === 0)
    return r[n++] = 1 << 24 | 64 << 16 | 0, r[n++] = 1 << 24 | 64 << 16 | 0, s.bits = 1, 0;
  for (m = 1; m < x && w[m] === 0; m++)
    ;
  for (l < m && (l = m), g = 1, a = 1; a <= M; a++)
    if (g <<= 1, g -= w[a], g < 0)
      return -1;
  if (g > 0 && (t === ce || x !== 1))
    return -1;
  for (k[1] = 0, a = 1; a < M; a++)
    k[a + 1] = k[a] + w[a];
  for (f = 0; f < o; f++)
    i[e + f] !== 0 && (d[k[i[e + f]]++] = f);
  if (t === ce ? (R = Z = d, v = 20) : t === J ? (R = Dt, Z = Ot, v = 257) : (R = Ct, Z = It, v = 0), p = 0, f = 0, a = m, h = n, u = l, S = 0, E = -1, _ = 1 << l, T = _ - 1, t === J && _ > le || t === de && _ > re)
    return 1;
  for (; ; ) {
    se = a - S, d[f] + 1 < v ? (B = 0, F = d[f]) : d[f] >= v ? (B = Z[d[f] - v], F = R[d[f] - v]) : (B = 96, F = 0), b = 1 << a - S, c = 1 << u, m = c;
    do
      c -= b, r[h + (p >> S) + c] = se << 24 | B << 16 | F | 0;
    while (c !== 0);
    for (b = 1 << a - 1; p & b; )
      b >>= 1;
    if (b !== 0 ? (p &= b - 1, p += b) : p = 0, f++, --w[a] === 0) {
      if (a === x)
        break;
      a = i[e + d[f]];
    }
    if (a > l && (p & T) !== E) {
      for (S === 0 && (S = l), h += m, u = a - S, g = 1 << u; u + S < x && (g -= w[u + S], !(g <= 0)); )
        u++, g <<= 1;
      if (_ += 1 << u, t === J && _ > le || t === de && _ > re)
        return 1;
      E = p & T, r[E] = l << 24 | u << 16 | h - n | 0;
    }
  }
  return p !== 0 && (r[h + p] = a - S << 24 | 64 << 16 | 0), s.bits = l, 0;
};
var z = Zt;
const Nt = 0, Pe = 1, je = 2, {
  Z_FINISH: he,
  Z_BLOCK: Ut,
  Z_TREES: K,
  Z_OK: N,
  Z_STREAM_END: Mt,
  Z_NEED_DICT: $t,
  Z_STREAM_ERROR: D,
  Z_DATA_ERROR: Xe,
  Z_MEM_ERROR: Ye,
  Z_BUF_ERROR: Lt,
  Z_DEFLATED: ue
} = Fe, Y = 16180, we = 16181, xe = 16182, _e = 16183, be = 16184, ke = 16185, ge = 16186, ve = 16187, Ee = 16188, pe = 16189, X = 16190, I = 16191, Q = 16192, ye = 16193, V = 16194, Re = 16195, Ae = 16196, me = 16197, Se = 16198, P = 16199, j = 16200, Te = 16201, De = 16202, Oe = 16203, Ce = 16204, Ie = 16205, q = 16206, Ze = 16207, Ne = 16208, A = 16209, We = 16210, Je = 16211, zt = 852, Ht = 592, Bt = 15, Ft = Bt, Ue = (t) => (t >>> 24 & 255) + (t >>> 8 & 65280) + ((t & 65280) << 8) + ((t & 255) << 24);
function Gt() {
  this.strm = null, this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new Uint16Array(320), this.work = new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
}
const U = (t) => {
  if (!t)
    return 1;
  const i = t.state;
  return !i || i.strm !== t || i.mode < Y || i.mode > Je ? 1 : 0;
}, Qe = (t) => {
  if (U(t))
    return D;
  const i = t.state;
  return t.total_in = t.total_out = i.total = 0, t.msg = "", i.wrap && (t.adler = i.wrap & 1), i.mode = Y, i.last = 0, i.havedict = 0, i.flags = -1, i.dmax = 32768, i.head = null, i.hold = 0, i.bits = 0, i.lencode = i.lendyn = new Int32Array(zt), i.distcode = i.distdyn = new Int32Array(Ht), i.sane = 1, i.back = -1, N;
}, Ve = (t) => {
  if (U(t))
    return D;
  const i = t.state;
  return i.wsize = 0, i.whave = 0, i.wnext = 0, Qe(t);
}, qe = (t, i) => {
  let e;
  if (U(t))
    return D;
  const o = t.state;
  return i < 0 ? (e = 0, i = -i) : (e = (i >> 4) + 5, i < 48 && (i &= 15)), i && (i < 8 || i > 15) ? D : (o.window !== null && o.wbits !== i && (o.window = null), o.wrap = e, o.wbits = i, Ve(t));
}, et = (t, i) => {
  if (!t)
    return D;
  const e = new Gt();
  t.state = e, e.strm = t, e.window = null, e.mode = Y;
  const o = qe(t, i);
  return o !== N && (t.state = null), o;
}, Kt = (t) => et(t, Ft);
let Me = !0, ee, te;
const Pt = (t) => {
  if (Me) {
    ee = new Int32Array(512), te = new Int32Array(32);
    let i = 0;
    for (; i < 144; )
      t.lens[i++] = 8;
    for (; i < 256; )
      t.lens[i++] = 9;
    for (; i < 280; )
      t.lens[i++] = 7;
    for (; i < 288; )
      t.lens[i++] = 8;
    for (z(Pe, t.lens, 0, 288, ee, 0, t.work, { bits: 9 }), i = 0; i < 32; )
      t.lens[i++] = 5;
    z(je, t.lens, 0, 32, te, 0, t.work, { bits: 5 }), Me = !1;
  }
  t.lencode = ee, t.lenbits = 9, t.distcode = te, t.distbits = 5;
}, tt = (t, i, e, o) => {
  let r;
  const n = t.state;
  return n.window === null && (n.window = new Uint8Array(1 << n.wbits)), n.wsize === 0 && (n.wsize = 1 << n.wbits, n.wnext = 0, n.whave = 0), o >= n.wsize ? (n.window.set(i.subarray(e - n.wsize, e), 0), n.wnext = 0, n.whave = n.wsize) : (r = n.wsize - n.wnext, r > o && (r = o), n.window.set(i.subarray(e - o, e - o + r), n.wnext), o -= r, o ? (n.window.set(i.subarray(e - o, e), 0), n.wnext = o, n.whave = n.wsize) : (n.wnext += r, n.wnext === n.wsize && (n.wnext = 0), n.whave < n.wsize && (n.whave += r))), 0;
}, jt = (t, i) => {
  let e, o, r, n, d, s, y, a, f, m, x, l, u, S, g = 0, _, p, b, c, E, T, h, R;
  const v = new Uint8Array(4);
  let w, k;
  const Z = (
    /* permutation of code lengths */
    new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15])
  );
  if (U(t) || !t.output || !t.input && t.avail_in !== 0)
    return D;
  e = t.state, e.mode === I && (e.mode = Q), d = t.next_out, r = t.output, y = t.avail_out, n = t.next_in, o = t.input, s = t.avail_in, a = e.hold, f = e.bits, m = s, x = y, R = N;
  e:
    for (; ; )
      switch (e.mode) {
        case Y:
          if (e.wrap === 0) {
            e.mode = Q;
            break;
          }
          for (; f < 16; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          if (e.wrap & 2 && a === 35615) {
            e.wbits === 0 && (e.wbits = 15), e.check = 0, v[0] = a & 255, v[1] = a >>> 8 & 255, e.check = O(e.check, v, 2, 0), a = 0, f = 0, e.mode = we;
            break;
          }
          if (e.head && (e.head.done = !1), !(e.wrap & 1) || /* check if zlib header allowed */
          (((a & 255) << 8) + (a >> 8)) % 31) {
            t.msg = "incorrect header check", e.mode = A;
            break;
          }
          if ((a & 15) !== ue) {
            t.msg = "unknown compression method", e.mode = A;
            break;
          }
          if (a >>>= 4, f -= 4, h = (a & 15) + 8, e.wbits === 0 && (e.wbits = h), h > 15 || h > e.wbits) {
            t.msg = "invalid window size", e.mode = A;
            break;
          }
          e.dmax = 1 << e.wbits, e.flags = 0, t.adler = e.check = 1, e.mode = a & 512 ? pe : I, a = 0, f = 0;
          break;
        case we:
          for (; f < 16; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          if (e.flags = a, (e.flags & 255) !== ue) {
            t.msg = "unknown compression method", e.mode = A;
            break;
          }
          if (e.flags & 57344) {
            t.msg = "unknown header flags set", e.mode = A;
            break;
          }
          e.head && (e.head.text = a >> 8 & 1), e.flags & 512 && e.wrap & 4 && (v[0] = a & 255, v[1] = a >>> 8 & 255, e.check = O(e.check, v, 2, 0)), a = 0, f = 0, e.mode = xe;
        /* falls through */
        case xe:
          for (; f < 32; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          e.head && (e.head.time = a), e.flags & 512 && e.wrap & 4 && (v[0] = a & 255, v[1] = a >>> 8 & 255, v[2] = a >>> 16 & 255, v[3] = a >>> 24 & 255, e.check = O(e.check, v, 4, 0)), a = 0, f = 0, e.mode = _e;
        /* falls through */
        case _e:
          for (; f < 16; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          e.head && (e.head.xflags = a & 255, e.head.os = a >> 8), e.flags & 512 && e.wrap & 4 && (v[0] = a & 255, v[1] = a >>> 8 & 255, e.check = O(e.check, v, 2, 0)), a = 0, f = 0, e.mode = be;
        /* falls through */
        case be:
          if (e.flags & 1024) {
            for (; f < 16; ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            e.length = a, e.head && (e.head.extra_len = a), e.flags & 512 && e.wrap & 4 && (v[0] = a & 255, v[1] = a >>> 8 & 255, e.check = O(e.check, v, 2, 0)), a = 0, f = 0;
          } else e.head && (e.head.extra = null);
          e.mode = ke;
        /* falls through */
        case ke:
          if (e.flags & 1024 && (l = e.length, l > s && (l = s), l && (e.head && (h = e.head.extra_len - e.length, e.head.extra || (e.head.extra = new Uint8Array(e.head.extra_len)), e.head.extra.set(
            o.subarray(
              n,
              // extra field is limited to 65536 bytes
              // - no need for additional size check
              n + l
            ),
            /*len + copy > state.head.extra_max - len ? state.head.extra_max : copy,*/
            h
          )), e.flags & 512 && e.wrap & 4 && (e.check = O(e.check, o, l, n)), s -= l, n += l, e.length -= l), e.length))
            break e;
          e.length = 0, e.mode = ge;
        /* falls through */
        case ge:
          if (e.flags & 2048) {
            if (s === 0)
              break e;
            l = 0;
            do
              h = o[n + l++], e.head && h && e.length < 65536 && (e.head.name += String.fromCharCode(h));
            while (h && l < s);
            if (e.flags & 512 && e.wrap & 4 && (e.check = O(e.check, o, l, n)), s -= l, n += l, h)
              break e;
          } else e.head && (e.head.name = null);
          e.length = 0, e.mode = ve;
        /* falls through */
        case ve:
          if (e.flags & 4096) {
            if (s === 0)
              break e;
            l = 0;
            do
              h = o[n + l++], e.head && h && e.length < 65536 && (e.head.comment += String.fromCharCode(h));
            while (h && l < s);
            if (e.flags & 512 && e.wrap & 4 && (e.check = O(e.check, o, l, n)), s -= l, n += l, h)
              break e;
          } else e.head && (e.head.comment = null);
          e.mode = Ee;
        /* falls through */
        case Ee:
          if (e.flags & 512) {
            for (; f < 16; ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            if (e.wrap & 4 && a !== (e.check & 65535)) {
              t.msg = "header crc mismatch", e.mode = A;
              break;
            }
            a = 0, f = 0;
          }
          e.head && (e.head.hcrc = e.flags >> 9 & 1, e.head.done = !0), t.adler = e.check = 0, e.mode = I;
          break;
        case pe:
          for (; f < 32; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          t.adler = e.check = Ue(a), a = 0, f = 0, e.mode = X;
        /* falls through */
        case X:
          if (e.havedict === 0)
            return t.next_out = d, t.avail_out = y, t.next_in = n, t.avail_in = s, e.hold = a, e.bits = f, $t;
          t.adler = e.check = 1, e.mode = I;
        /* falls through */
        case I:
          if (i === Ut || i === K)
            break e;
        /* falls through */
        case Q:
          if (e.last) {
            a >>>= f & 7, f -= f & 7, e.mode = q;
            break;
          }
          for (; f < 3; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          switch (e.last = a & 1, a >>>= 1, f -= 1, a & 3) {
            case 0:
              e.mode = ye;
              break;
            case 1:
              if (Pt(e), e.mode = P, i === K) {
                a >>>= 2, f -= 2;
                break e;
              }
              break;
            case 2:
              e.mode = Ae;
              break;
            case 3:
              t.msg = "invalid block type", e.mode = A;
          }
          a >>>= 2, f -= 2;
          break;
        case ye:
          for (a >>>= f & 7, f -= f & 7; f < 32; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          if ((a & 65535) !== (a >>> 16 ^ 65535)) {
            t.msg = "invalid stored block lengths", e.mode = A;
            break;
          }
          if (e.length = a & 65535, a = 0, f = 0, e.mode = V, i === K)
            break e;
        /* falls through */
        case V:
          e.mode = Re;
        /* falls through */
        case Re:
          if (l = e.length, l) {
            if (l > s && (l = s), l > y && (l = y), l === 0)
              break e;
            r.set(o.subarray(n, n + l), d), s -= l, n += l, y -= l, d += l, e.length -= l;
            break;
          }
          e.mode = I;
          break;
        case Ae:
          for (; f < 14; ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          if (e.nlen = (a & 31) + 257, a >>>= 5, f -= 5, e.ndist = (a & 31) + 1, a >>>= 5, f -= 5, e.ncode = (a & 15) + 4, a >>>= 4, f -= 4, e.nlen > 286 || e.ndist > 30) {
            t.msg = "too many length or distance symbols", e.mode = A;
            break;
          }
          e.have = 0, e.mode = me;
        /* falls through */
        case me:
          for (; e.have < e.ncode; ) {
            for (; f < 3; ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            e.lens[Z[e.have++]] = a & 7, a >>>= 3, f -= 3;
          }
          for (; e.have < 19; )
            e.lens[Z[e.have++]] = 0;
          if (e.lencode = e.lendyn, e.lenbits = 7, w = { bits: e.lenbits }, R = z(Nt, e.lens, 0, 19, e.lencode, 0, e.work, w), e.lenbits = w.bits, R) {
            t.msg = "invalid code lengths set", e.mode = A;
            break;
          }
          e.have = 0, e.mode = Se;
        /* falls through */
        case Se:
          for (; e.have < e.nlen + e.ndist; ) {
            for (; g = e.lencode[a & (1 << e.lenbits) - 1], _ = g >>> 24, p = g >>> 16 & 255, b = g & 65535, !(_ <= f); ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            if (b < 16)
              a >>>= _, f -= _, e.lens[e.have++] = b;
            else {
              if (b === 16) {
                for (k = _ + 2; f < k; ) {
                  if (s === 0)
                    break e;
                  s--, a += o[n++] << f, f += 8;
                }
                if (a >>>= _, f -= _, e.have === 0) {
                  t.msg = "invalid bit length repeat", e.mode = A;
                  break;
                }
                h = e.lens[e.have - 1], l = 3 + (a & 3), a >>>= 2, f -= 2;
              } else if (b === 17) {
                for (k = _ + 3; f < k; ) {
                  if (s === 0)
                    break e;
                  s--, a += o[n++] << f, f += 8;
                }
                a >>>= _, f -= _, h = 0, l = 3 + (a & 7), a >>>= 3, f -= 3;
              } else {
                for (k = _ + 7; f < k; ) {
                  if (s === 0)
                    break e;
                  s--, a += o[n++] << f, f += 8;
                }
                a >>>= _, f -= _, h = 0, l = 11 + (a & 127), a >>>= 7, f -= 7;
              }
              if (e.have + l > e.nlen + e.ndist) {
                t.msg = "invalid bit length repeat", e.mode = A;
                break;
              }
              for (; l--; )
                e.lens[e.have++] = h;
            }
          }
          if (e.mode === A)
            break;
          if (e.lens[256] === 0) {
            t.msg = "invalid code -- missing end-of-block", e.mode = A;
            break;
          }
          if (e.lenbits = 9, w = { bits: e.lenbits }, R = z(Pe, e.lens, 0, e.nlen, e.lencode, 0, e.work, w), e.lenbits = w.bits, R) {
            t.msg = "invalid literal/lengths set", e.mode = A;
            break;
          }
          if (e.distbits = 6, e.distcode = e.distdyn, w = { bits: e.distbits }, R = z(je, e.lens, e.nlen, e.ndist, e.distcode, 0, e.work, w), e.distbits = w.bits, R) {
            t.msg = "invalid distances set", e.mode = A;
            break;
          }
          if (e.mode = P, i === K)
            break e;
        /* falls through */
        case P:
          e.mode = j;
        /* falls through */
        case j:
          if (s >= 6 && y >= 258) {
            t.next_out = d, t.avail_out = y, t.next_in = n, t.avail_in = s, e.hold = a, e.bits = f, Tt(t, x), d = t.next_out, r = t.output, y = t.avail_out, n = t.next_in, o = t.input, s = t.avail_in, a = e.hold, f = e.bits, e.mode === I && (e.back = -1);
            break;
          }
          for (e.back = 0; g = e.lencode[a & (1 << e.lenbits) - 1], _ = g >>> 24, p = g >>> 16 & 255, b = g & 65535, !(_ <= f); ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          if (p && (p & 240) === 0) {
            for (c = _, E = p, T = b; g = e.lencode[T + ((a & (1 << c + E) - 1) >> c)], _ = g >>> 24, p = g >>> 16 & 255, b = g & 65535, !(c + _ <= f); ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            a >>>= c, f -= c, e.back += c;
          }
          if (a >>>= _, f -= _, e.back += _, e.length = b, p === 0) {
            e.mode = Ie;
            break;
          }
          if (p & 32) {
            e.back = -1, e.mode = I;
            break;
          }
          if (p & 64) {
            t.msg = "invalid literal/length code", e.mode = A;
            break;
          }
          e.extra = p & 15, e.mode = Te;
        /* falls through */
        case Te:
          if (e.extra) {
            for (k = e.extra; f < k; ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            e.length += a & (1 << e.extra) - 1, a >>>= e.extra, f -= e.extra, e.back += e.extra;
          }
          e.was = e.length, e.mode = De;
        /* falls through */
        case De:
          for (; g = e.distcode[a & (1 << e.distbits) - 1], _ = g >>> 24, p = g >>> 16 & 255, b = g & 65535, !(_ <= f); ) {
            if (s === 0)
              break e;
            s--, a += o[n++] << f, f += 8;
          }
          if ((p & 240) === 0) {
            for (c = _, E = p, T = b; g = e.distcode[T + ((a & (1 << c + E) - 1) >> c)], _ = g >>> 24, p = g >>> 16 & 255, b = g & 65535, !(c + _ <= f); ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            a >>>= c, f -= c, e.back += c;
          }
          if (a >>>= _, f -= _, e.back += _, p & 64) {
            t.msg = "invalid distance code", e.mode = A;
            break;
          }
          e.offset = b, e.extra = p & 15, e.mode = Oe;
        /* falls through */
        case Oe:
          if (e.extra) {
            for (k = e.extra; f < k; ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            e.offset += a & (1 << e.extra) - 1, a >>>= e.extra, f -= e.extra, e.back += e.extra;
          }
          if (e.offset > e.dmax) {
            t.msg = "invalid distance too far back", e.mode = A;
            break;
          }
          e.mode = Ce;
        /* falls through */
        case Ce:
          if (y === 0)
            break e;
          if (l = x - y, e.offset > l) {
            if (l = e.offset - l, l > e.whave && e.sane) {
              t.msg = "invalid distance too far back", e.mode = A;
              break;
            }
            l > e.wnext ? (l -= e.wnext, u = e.wsize - l) : u = e.wnext - l, l > e.length && (l = e.length), S = e.window;
          } else
            S = r, u = d - e.offset, l = e.length;
          l > y && (l = y), y -= l, e.length -= l;
          do
            r[d++] = S[u++];
          while (--l);
          e.length === 0 && (e.mode = j);
          break;
        case Ie:
          if (y === 0)
            break e;
          r[d++] = e.length, y--, e.mode = j;
          break;
        case q:
          if (e.wrap) {
            for (; f < 32; ) {
              if (s === 0)
                break e;
              s--, a |= o[n++] << f, f += 8;
            }
            if (x -= y, t.total_out += x, e.total += x, e.wrap & 4 && x && (t.adler = e.check = /*UPDATE_CHECK(state.check, put - _out, _out);*/
            e.flags ? O(e.check, r, x, d - x) : ae(e.check, r, x, d - x)), x = y, e.wrap & 4 && (e.flags ? a : Ue(a)) !== e.check) {
              t.msg = "incorrect data check", e.mode = A;
              break;
            }
            a = 0, f = 0;
          }
          e.mode = Ze;
        /* falls through */
        case Ze:
          if (e.wrap && e.flags) {
            for (; f < 32; ) {
              if (s === 0)
                break e;
              s--, a += o[n++] << f, f += 8;
            }
            if (e.wrap & 4 && a !== (e.total & 4294967295)) {
              t.msg = "incorrect length check", e.mode = A;
              break;
            }
            a = 0, f = 0;
          }
          e.mode = Ne;
        /* falls through */
        case Ne:
          R = Mt;
          break e;
        case A:
          R = Xe;
          break e;
        case We:
          return Ye;
        case Je:
        /* falls through */
        default:
          return D;
      }
  return t.next_out = d, t.avail_out = y, t.next_in = n, t.avail_in = s, e.hold = a, e.bits = f, (e.wsize || x !== t.avail_out && e.mode < A && (e.mode < q || i !== he)) && tt(t, t.output, t.next_out, x - t.avail_out), m -= t.avail_in, x -= t.avail_out, t.total_in += m, t.total_out += x, e.total += x, e.wrap & 4 && x && (t.adler = e.check = /*UPDATE_CHECK(state.check, strm.next_out - _out, _out);*/
  e.flags ? O(e.check, r, x, t.next_out - x) : ae(e.check, r, x, t.next_out - x)), t.data_type = e.bits + (e.last ? 64 : 0) + (e.mode === I ? 128 : 0) + (e.mode === P || e.mode === V ? 256 : 0), (m === 0 && x === 0 || i === he) && R === N && (R = Lt), R;
}, Xt = (t) => {
  if (U(t))
    return D;
  let i = t.state;
  return i.window && (i.window = null), t.state = null, N;
}, Yt = (t, i) => {
  if (U(t))
    return D;
  const e = t.state;
  return (e.wrap & 2) === 0 ? D : (e.head = i, i.done = !1, N);
}, Wt = (t, i) => {
  const e = i.length;
  let o, r, n;
  return U(t) || (o = t.state, o.wrap !== 0 && o.mode !== X) ? D : o.mode === X && (r = 1, r = ae(r, i, e, 0), r !== o.check) ? Xe : (n = tt(t, i, e, e), n ? (o.mode = We, Ye) : (o.havedict = 1, N));
};
var Jt = Ve, Qt = qe, Vt = Qe, qt = Kt, ei = et, ti = jt, ii = Xt, ni = Yt, ai = Wt, fi = "pako inflate (from Nodeca project)", C = {
  inflateReset: Jt,
  inflateReset2: Qt,
  inflateResetKeep: Vt,
  inflateInit: qt,
  inflateInit2: ei,
  inflate: ti,
  inflateEnd: ii,
  inflateGetHeader: ni,
  inflateSetDictionary: ai,
  inflateInfo: fi
};
function oi() {
  this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
}
var si = oi;
const it = Object.prototype.toString, {
  Z_NO_FLUSH: li,
  Z_FINISH: $e,
  Z_OK: $,
  Z_STREAM_END: ie,
  Z_NEED_DICT: ne,
  Z_STREAM_ERROR: ri,
  Z_DATA_ERROR: Le,
  Z_MEM_ERROR: ci,
  Z_BUF_ERROR: ze
} = Fe, di = {
  chunkSize: 1024 * 64,
  windowBits: 15,
  to: ""
};
function W(t) {
  this.options = Ge.assign({}, di, t || {});
  const i = this.options;
  i.raw && i.windowBits >= 0 && i.windowBits < 16 && (i.windowBits = -i.windowBits, i.windowBits === 0 && (i.windowBits = -15)), i.windowBits >= 0 && i.windowBits < 16 && !(t && t.windowBits) && (i.windowBits += 32), i.windowBits > 15 && i.windowBits < 48 && (i.windowBits & 15) === 0 && (i.windowBits |= 15), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new mt(), this.strm.avail_out = 0;
  let e = C.inflateInit2(
    this.strm,
    i.windowBits
  );
  if (e !== $)
    throw new Error(fe[e]);
  if (this.header = new si(), C.inflateGetHeader(this.strm, this.header), i.dictionary && (typeof i.dictionary == "string" ? i.dictionary = oe.string2buf(i.dictionary) : it.call(i.dictionary) === "[object ArrayBuffer]" && (i.dictionary = new Uint8Array(i.dictionary)), i.raw && (e = C.inflateSetDictionary(this.strm, i.dictionary), e !== $)))
    throw new Error(fe[e]);
}
W.prototype.push = function(t, i) {
  const e = this.strm, o = this.options.chunkSize, r = this.options.dictionary;
  let n, d, s;
  if (this.ended) return !1;
  for (i === ~~i ? d = i : d = i === !0 ? $e : li, it.call(t) === "[object ArrayBuffer]" ? e.input = new Uint8Array(t) : e.input = t, e.next_in = 0, e.avail_in = e.input.length; ; ) {
    for (e.avail_out === 0 && (e.output = new Uint8Array(o), e.next_out = 0, e.avail_out = o), n = C.inflate(e, d), n === ne && r && (n = C.inflateSetDictionary(e, r), n === $ ? n = C.inflate(e, d) : n === Le && (n = ne)); e.avail_in > 0 && n === ie && e.state.wrap & 2 && e.state.flags !== 0 && e.input[e.next_in] !== 0; )
      C.inflateReset(e), n = C.inflate(e, d);
    switch (n) {
      case ri:
      case Le:
      case ne:
      case ci:
        return this.onEnd(n), this.ended = !0, !1;
    }
    if (s = e.avail_out, e.next_out && (e.avail_out === 0 || n === ie || d > 0))
      if (this.options.to === "string") {
        let y = oe.utf8border(e.output, e.next_out), a = e.next_out - y, f = oe.buf2string(e.output, y);
        e.next_out = a, e.avail_out = o - a, a && e.output.set(e.output.subarray(y, y + a), 0), this.onData(f);
      } else
        this.onData(e.output.length === e.next_out ? e.output : e.output.subarray(0, e.next_out)), e.avail_out = 0, e.next_out = 0;
    if (!((n === $ || n === ze) && s === 0)) {
      if (n === ie)
        return n = C.inflateEnd(this.strm), this.onEnd(n), this.ended = !0, !0;
      if (e.avail_in === 0) {
        if (d === $e)
          return n = C.inflateEnd(this.strm), this.onEnd(n === $ ? ze : n), this.ended = !0, !1;
        break;
      }
    }
  }
  return !0;
};
W.prototype.onData = function(t) {
  this.chunks.push(t);
};
W.prototype.onEnd = function(t) {
  t === $ && (this.options.to === "string" ? this.result = this.chunks.join("") : this.result = Ge.flattenChunks(this.chunks)), this.chunks = [], this.err = t, this.msg = this.strm.msg;
};
function hi(t, i) {
  const e = new W(i);
  if (e.push(t, !0), e.err) throw e.msg || fe[e.err];
  return e.result;
}
var ui = hi, wi = {
  inflate: ui
};
const { inflate: xi } = wi;
var _i = xi;
export {
  _i as i
};
